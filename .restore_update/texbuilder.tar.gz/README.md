TeXbuilder
==========

TeXbuilder is a framework with the purpose of making even easier the creation of LaTeX documents.

You can create a new LaTeX project, using the ppgccufmg template, with the command:
```shell
texbuild-project thesis ppgccufmg
```
After having created the project, you can compile it with the command:
```shell
texbuild thesis
```

After being compiled, a PDF file will be created at the ./bin folder.
